package com.example.column;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
