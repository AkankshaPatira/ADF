import 'package:flutter/material.dart';
void main() {
  runApp(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: Colors.black, appBar: AppBar(
          title: const Text("Hello World "),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
        ),
          body: Text(" Akanksha Patira here",
            style: TextStyle(backgroundColor: Colors.white),),
        ),
      )
  );
}