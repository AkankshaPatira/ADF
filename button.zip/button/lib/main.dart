import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}
class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(

        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
    title: Text(widget.title),
    ),
    body: Center(
    child: Column(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: <Widget>[
    RichText(
    text: TextSpan(
    text: 'Akanksha',
    style: TextStyle(
    color: Colors.green,
    backgroundColor: Colors.black87,
    fontSize:40,
    ),
    children: [
      TextSpan(text: 'Patira',style: TextStyle(
          fontSize: 40,
          color: Colors.amberAccent
      )
      )
    ]
    ),
    ),
        ElevatedButton
          ( style: ElevatedButton.styleFrom(foregroundColor: Colors.black87,backgroundColor:
        Colors.teal,textStyle: const TextStyle(fontSize: 10)),
            onPressed: (){},
            child: const Text('Elevated Button')
        ),
        TextButton(
          // style: TextButton.styleFrom(foregroundColor: Colors.black87,backgroundColor:
           // Colors.grey,
           // textStyle: const TextStyle(fontStyle: FontStyle.italic)),
            onPressed: (){},
        child: const Text('Text Button')
    ),
    OutlinedButton(
    style: OutlinedButton.styleFrom(foregroundColor: Colors.black87,
    backgroundColor:Colors.brown,
    shape: BeveledRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10)))),
    onPressed: (){},
    child: const Text('Outlined Button')
    ),
    IconButton(
    iconSize: 100,
    icon: const Icon(
    Icons.access_time_filled_rounded,
    ),
    onPressed: (){},
    ),
    FloatingActionButton(onPressed: (){},
    backgroundColor: Colors.cyan,
    child: Icon(Icons.abc_rounded),),
    ],
    ),
    ),
    );
  }
}
