package com.example.row;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
